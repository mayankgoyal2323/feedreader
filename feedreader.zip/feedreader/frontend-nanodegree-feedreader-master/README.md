About the Project
In this project we are given a web-based application that reads RSS feeds by Udacity. The tests are added using Jasmine to check the functionalites of the code written.

How to run the Project
Open index.html in your browser and watch

Technologies Used
Jasmine
jQuery
HTML5/CSS3